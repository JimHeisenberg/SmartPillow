#include "./esp8266/esp8266.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "./usart/bsp_usart.h"
#include "./rtc/bsp_rtc.h"
#include "./adc/bsp_adc.h"
#include "./beep/bsp_beep.h" 

extern uint8_t issleep;
extern uint32_t version;
/*ESP8266��Ҫ��ǰ��ɵ�����
*1.����ΪAPģʽ
*2.����wifi��д��flash��
*3.����TCP AT+CIPSTART="TCP","212.64.54.38",54321��д��flash��
*
*/
void ESP8266_Init(){
	


}

void ESP8266_SendData(char *data,int length){
	printf("AT+CIPSEND=%d",length);
	printf("%s",data);
}

void ESP8266_ReceiveData(char *data){
	char* point;
//	printf("receive data:\n%s\n\n",data);
	if(0){
		//�豸ID����ȷ
	}
	if((point=FindValue(data,"IsSleeping"))!=NULL){
		if(*point=='1'){
			BEEP(OFF);
		}else if(*point=='0'){
			BEEP(ON);
		}
		
	}
	return;
}

char* FindStringValue(char* point,char* key){
	//ע��ð�ź���һ��Ҫ�пո�
	//"name": "xiaoming"
	char *aim;
	if((aim = strstr(point,key))!=NULL){
		aim = aim + strlen(key) + 4;
		return aim;
	}
	return NULL;
}

char* FindValue(char* point,char* key){
	//ע��ð�ź���һ��Ҫ�пո�
	//"name": "xiaoming"
	char *aim;
	if((aim = strstr(point,key))!=NULL){
		aim = aim + strlen(key) + 3;
		return aim;
	}
	return NULL;
}
